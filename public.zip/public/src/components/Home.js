import React from 'react';
import './Home.css';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div className="home-wrapper">
      <nav className="navbar">
        <div className="logo">🎒 Lost & Found</div>
        <ul className="nav-links">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/login">Login</Link></li>
          <li><Link to="/dashboard">Dashboard</Link></li>
        </ul>
      </nav>

      <div className="home-content">
        <h1>Welcome to the Lost & Found Portal</h1>
        <p>Report lost or found items and help reunite owners with their belongings.</p>
        <div className="home-buttons">
          <Link to="/login" className="home-btn">Login</Link>
          <Link to="/dashboard" className="home-btn">Dashboard</Link>
        </div>
      </div>
    </div>
  );
}

export default Home;
