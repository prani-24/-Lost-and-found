import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // ✅ Step 1: Import useNavigate

function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate(); // ✅ Step 2: Initialize navigate

  const handleLogin = () => {
    if (!username || !password) {
      setMessage("⚠ Enter both username and password");
      return;
    }

    let users = JSON.parse(localStorage.getItem('users')) || [];
    const existing = users.find(u => u.username === username);

    if (existing) {
      if (existing.password === password) {
        onLogin(username);
        setMessage("✅ Logged in");
        navigate('/dashboard'); // ✅ Step 3: Navigate after successful login
      } else {
        setMessage("❌ Wrong password");
      }
    } else {
      users.push({ username, password });
      localStorage.setItem('users', JSON.stringify(users));
      onLogin(username);
      setMessage("🆕 Registered & logged in");
      navigate('/dashboard'); // ✅ Step 4: Navigate after registration
    }
  };

  return (
   <div className="login-container">
      <h2>🔐 Lost & Found Board</h2>
      <div className="login-box">
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={e => setUsername(e.target.value)}
          className="login-input"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          className="login-input"
        />
        <button className="login-button" onClick={handleLogin}>Login</button>
        {message && <p className="error">{message}</p>}
      </div>
    </div>
  );
}

export default Login;