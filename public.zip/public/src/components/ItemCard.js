import React from 'react';

function ItemCard({ item, index, currentUser, onClaim }) {
  const isOwner = item.user === currentUser;

  return (
    <div className="item-card">
      <h4>{item.title} ({item.type})</h4>
      <p>{item.description}</p>
      <p>Status: <strong>{item.status}</strong></p>
      <p>Reported by: {item.user}</p>
      {item.status === 'Matched' && isOwner && item.type === 'Lost' && (
        <button onClick={() => onClaim(index)}>✅ Claim Item</button>
      )}
      {item.status === 'Claimed' && isOwner && item.type === 'Found' && (
        <p className="claimed-msg">🎉 Your found item has been claimed.</p>
      )}
    </div>
  );
}

export default ItemCard;
