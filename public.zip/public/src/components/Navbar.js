// src/components/Navbar.js
import React from 'react';
import { Link } from 'react-router-dom';

function Navbar({ currentUser }) {
  return (
    <nav className="navbar">
      <Link to="/">Home</Link>
      {currentUser && <Link to="/dashboard">Dashboard</Link>}
      {currentUser === 'admin' && <Link to="/view-items">View Items</Link>}
      {!currentUser && <Link to="/login">Login</Link>}
    </nav>
  );
}

export default Navbar;
