import React, { useState } from 'react';

function ItemForm({ onAddItem }) {
  const [title, setTitle] = useState('');
  const [description, setDesc] = useState('');
  const [type, setType] = useState('Lost');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !description) return alert("All fields required");
    onAddItem({ title, description, type });
    setTitle('');
    setDesc('');
    setType('Lost');
  };

  return (
    <form onSubmit={handleSubmit} className="form">
      <h3>📝 Report Item</h3>
      <input placeholder="Item title" value={title} onChange={e => setTitle(e.target.value)} />
      <textarea placeholder="Description" value={description} onChange={e => setDesc(e.target.value)} />
      <select value={type} onChange={e => setType(e.target.value)}>
        <option>Lost</option>
        <option>Found</option>
      </select>
      <button type="submit">Submit</button>
    </form>
  );
}

export default ItemForm;
