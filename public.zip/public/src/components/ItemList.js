import React from 'react';
import ItemCard from './ItemCard';

function ItemList({ items, currentUser, onClaim }) {
  return (
    <div className="item-list">
      <h3>📦 Reported Items</h3>
      {items.length === 0 ? <p>No items yet.</p> : (
        items.map((item, idx) => (
          <ItemCard
            key={idx}
            item={item}
            index={idx}
            currentUser={currentUser}
            onClaim={onClaim}
          />
        ))
      )}
    </div>
  );
}

export default ItemList;
