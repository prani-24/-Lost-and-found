import React, { useState, useEffect } from 'react';
import ItemCard from './ItemCard';
import ItemForm from './ItemForm';

function Dashboard({ currentUser, onLogout }) {
  const [items, setItems] = useState([]);
  const [matches, setMatches] = useState([]);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem('items')) || [];
    setItems(stored);

    const userItems = stored.filter(i => i.username === currentUser);
    const potentialMatches = stored.filter(
      i =>
        i.username !== currentUser &&
        userItems.some(u =>
          u.title.toLowerCase() === i.title.toLowerCase() &&
          u.description.toLowerCase() === i.description.toLowerCase() &&
          u.type !== i.type
        )
    );
    setMatches(potentialMatches);
  }, [currentUser]);

  const handleAddItem = (item) => {
    const updated = [...items, { ...item, username: currentUser, status: 'Pending' }];
    setItems(updated);
    localStorage.setItem('items', JSON.stringify(updated));
  };

  const handleClaim = (title, description) => {
    const updated = items.map(i => {
      if (
        i.title.toLowerCase() === title.toLowerCase() &&
        i.description.toLowerCase() === description.toLowerCase()
      ) {
        return { ...i, status: 'Claimed' };
      }
      return i;
    });
    setItems(updated);
    localStorage.setItem('items', JSON.stringify(updated));
    alert('Item successfully claimed!');
  };

  const handleReset = () => {
    localStorage.removeItem('items');
    setItems([]);
    setMatches([]);
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h2>Welcome, <span className="highlight">{currentUser}</span>!</h2>
        <div className="dashboard-actions">
          <button onClick={onLogout}>🔒 Logout</button>
          <button className="reset" onClick={handleReset}>♻ Reset</button>
        </div>
      </div>

      <div className="dashboard-content">
        <div className="form-section">
          <ItemForm onAddItem={handleAddItem} />
        </div>

        <div className="list-section">
          <h3>📦 Reported Items</h3>
          {items.filter(i => i.username === currentUser).length === 0 ? (
            <p>No items yet.</p>
          ) : (
            items
              .filter(i => i.username === currentUser)
              .map((item, idx) => <ItemCard key={idx} item={item} />)
          )}
        </div>
      </div>

      {matches.length > 0 && (
        <div className="match-section">
          <h3>🔔 Possible Matches Found</h3>
          {matches.map((match, idx) => (
            <div className="item-card" key={idx}>
              <p><strong>{match.title}</strong></p>
              <p>{match.description}</p>
              <p>{match.username}</p>
              <button onClick={() => handleClaim(match.title, match.description)}>Claim</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Dashboard;
